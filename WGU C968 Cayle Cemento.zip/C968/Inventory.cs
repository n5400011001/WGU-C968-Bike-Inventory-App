﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace C968
{
    class Inventory
    {
        public static BindingList<Part> allParts = new BindingList<Part>();
        public static BindingList<Product> allProducts = new BindingList<Product>();

        private static int partIndex = 0;
        private static int productIndex = 0;

        public static int PartIndex
        {
            get { return partIndex; }
        }

        public static int ProductIndex
        {
            get { return productIndex; }
        }

        public static void addPart(Part newPart)
        {
            allParts.Add(newPart);
            newPart.ID = partIndex;
            partIndex++;
        }

        public static void addProduct(Product newProduct)
        {
            allProducts.Add(newProduct);
            newProduct.ID = productIndex;
            productIndex++;
        }

    }
}
